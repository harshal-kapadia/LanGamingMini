<html>
<head>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="base.css">
<link rel="stylesheet" href="boot.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<title>LAN GAMING - Registration</title>
</head>
<body>
<nav class="navbar navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<a class="navbar-brand" href="#">KEEP GAMING</a>
</div>
<ul class="nav navbar-nav">
<li><a href="home.html">Home</a></li>
<li><a href="list.php">Teams List</a></li>
<li><a href="about.html">About Us</a></li>
</ul>
<a href="registration.html"><button class="btn btn-danger navbar-btn" style="float:right;">REGISTER</button></a>
</div>
</nav>
<?php
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("lanreg",$conn);
$query1="INSERT into lanreg VALUES ('$_POST[CN]','$_POST[IN]','$_POST[email_id]','$_POST[age]','$_POST[city]','$_POST[add]','$_POST[teamn]','$_POST[mname]','$_POST[cno]','$_POST[cs]','$_POST[csgo]','$_POST[dota]','$_POST[lol]','$_POST[gender]')";
$result=mysql_query($query1,$conn);
echo "<h2>Thank You For Registering</h2>";
mysql_close($conn);
?>
<p align="center">
<b><big>Developed By</big></b><br>
Web Developers<br></p>
</body>
</html>