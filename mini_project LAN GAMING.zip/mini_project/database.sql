-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 21, 2017 at 08:26 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lanreg`
--

-- --------------------------------------------------------

--
-- Table structure for table `lanreg`
--

CREATE TABLE IF NOT EXISTS `lanreg` (
  `CN` longtext NOT NULL,
  `IN` varchar(15) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `age` int(2) NOT NULL,
  `city` text NOT NULL,
  `add` longtext NOT NULL,
  `teamn` varchar(15) NOT NULL,
  `mname` text NOT NULL,
  `cno` int(10) NOT NULL,
  `cs` varchar(10) NOT NULL,
  `csgo` varchar(10) NOT NULL,
  `dota` varchar(10) NOT NULL,
  `lol` varchar(10) NOT NULL,
  `gender` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lanreg`
--

INSERT INTO `lanreg` (`CN`, `IN`, `email_id`, `age`, `city`, `add`, `teamn`, `mname`, `cno`, `cs`, `csgo`, `dota`, `lol`, `gender`) VALUES
('asdd', 'adad', 'harshal.k@gmail.com', 21, 'mum', 'hello arj sucks', 'matrix+789', 'asqweetfjafgsg', 2147483647, 'cs', 'csgo', 'dota', '', 'male'),
('asa', 'werrt', 'asd.kjl@gmail.com', 12, 'mum', 'asdf,backstreet boys', 'amtrix_!23', 'asdd,werrty,ghjl', 98745613, 'cs', 'csgo', '', '', 'male'),
('', '', '', 0, 'mum', '', '', 'fhxh', 0, '', '', '', '', 'male'),
('', '', '', 0, 'mum', '', '', '', 0, '', '', '', '', 'male'),
('adadaf', '', '', 0, 'mum', '', '', '', 0, '', '', '', '', 'male'),
('asDAFD', '', '', 0, 'mum', '', '', '', 0, '', '', '', '', 'male'),
('aascadcs', '', 'hk@gmail.com', 0, 'mum', '', '', '', 0, '', '', '', '', 'male'),
('asDAFD', 'qwerty', 'h@gmail.com', 21, 'del', 'wall street,USA', 'rippers', 'arj,harsh,jp,money', 2147483647, 'cs', 'csgo', '', '', 'male'),
('asd', 'qwer', 'h@gmail.com', 21, 'mum', 'wall street,USA', 'asd123', 'jp,money,hk07', 2147483647, 'cs', 'csgo', '', '', 'male'),
('asdd', 'qwe', 'h@gmail.com', 21, 'mum', 'wall stret', 'afsgdf', 'qwer,addf,hjjku', 2147483647, '', 'csgo', 'dota', 'lol', 'male'),
('pRASHAM', 'PLAYER', 'pras@hmlail.com', 19, 'mum', 'gesg', 'ballers', 'nini,cdcvdvc,vfdb', 2147483647, 'cs', 'csgo', '', '', 'male'),
('Jay Parekh', 'astarrR', 'matrix@d2d.com', 20, 'mum', 'DJ Sanghvi College Address', 'Dare2Dream', 'blackhawk, HellrangeR, antidote, SpawN', 2147483647, 'cs', 'csgo', 'dota', 'lol', 'male');
